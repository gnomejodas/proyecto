

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Inicio</title>
        
        <link rel="stylesheet" type="text/css" href="./lib/css/fondo.css">
    </head>
    <body>
        <!--Incluimos el menú de navegación-->
        <?php
            require_once './src/vistas/nav.php';
        ?>
    </body>
</html>






