<style>
    
  ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: green;
}
.active {
    
    background-color: orange;
}
</style>
    <ul>
        <li><a href="./" class="active">Inicio</a></li>
        <li><a href="./?site=dhcp">DHCP</a></li>
        <!--  <li><a href="#contact">Contact</a></li>
          <li><a href="#about">About</a></li>-->
    </ul>